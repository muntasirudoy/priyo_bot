import axios from 'axios';

const viteEnv = (import.meta as ImportMeta & {
  env?: {
    VITE_API_URL?: string;
  };
}).env;

export const api = axios.create({
  baseURL: new URLSearchParams(window.location.search).get('apiBase') || viteEnv?.VITE_API_URL || '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor to inject JWT from localStorage
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('support_admin_token');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Interceptor to handle unauthenticated responses
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // If token expired on admin route, clear token
      if (window.location.pathname.startsWith('/admin') && window.location.pathname !== '/admin/login') {
        localStorage.removeItem('support_admin_token');
        window.location.href = '/admin/login';
      }
    }
    return Promise.reject(error);
  }
);
